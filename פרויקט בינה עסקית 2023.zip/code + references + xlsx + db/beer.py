import pandas as pd
import sqlite3


class Database:
    def __init__(self):
        self.product_data = None
        self.transaction_data = None

    def extract_product_data(self):
        try:
            self.product_data = pd.read_csv('Product_range.csv', encoding='latin-1')
            self.product_data.dropna(inplace=True)
        except FileNotFoundError:
            print("Product_range.csv file not found.")

    def extract_transaction_data(self):
        try:
            self.transaction_data = pd.read_csv('Transactions.csv', encoding='latin-1')
            self.transaction_data.dropna(inplace=True)
        except FileNotFoundError:
            print("Transactions.csv file not found.")

    def transform_product_data(self):
        transformed_product_data = self.product_data.rename(columns={
            'Product Code': 'Product_code',
            'Vendor Code': 'Vendor_code',
            'Name': 'Name',
            'Retail Price': 'Retail_price',
            'Base Unit': 'Base_unit',
            'Country of Origin': 'Country_of_Origin',
            'Size': 'Size',
            'ABV': 'ABV'
        })
        return transformed_product_data

    def transform_transaction_data(self):
        transformed_transaction_data = self.transaction_data.rename(columns={
            'Date and Time of Unloading': 'Date_and_time_of_unloading',
            'Product Code': 'Product_code',
            'Amount': 'Amount',
            'Sale Amount': 'Sale_amount',
            'Discount Amount': 'Discount_amount',
            'Profit': 'Profit',
            'Percentage Markup': 'Percentage_markup',
            'Discount Percentage': 'Discount_percentage'
        })[['Date_and_time_of_unloading', 'Product_code', 'Amount', 'Sale_amount', 'Discount_amount',
            'Profit', 'Percentage_markup', 'Discount_percentage']].copy()
        return transformed_transaction_data

    def merge_data(self):
        merged_data = pd.merge(self.transform_product_data(), self.transform_transaction_data(), on='Product_code')
        return merged_data

    def load_merged_data(self):
        conn = sqlite3.connect('beers_data.db')
        merged_data = self.merge_data()
        merged_data.to_sql('beers_data', conn, if_exists='replace', index=False)
        conn.close()
        print("Merged data successfully loaded to the database.")
        print(merged_data)

    def calculate_most_profitable_month(self):
        merged_data = self.merge_data()
        merged_data['Month'] = pd.to_datetime(merged_data['Date_and_time_of_unloading']).dt.month
        monthly_profit = merged_data.groupby('Month')['Profit'].sum()
        most_profitable_month_profit = monthly_profit.idxmax()
        monthly_quantity = merged_data.groupby('Month')['Amount'].sum()
        most_profitable_month_quantity = monthly_quantity.idxmax()

        return most_profitable_month_profit, most_profitable_month_quantity

    def calculate_best_selling_product(self):
        merged_data = self.merge_data()
        best_selling_product = merged_data.groupby('Name')['Amount'].sum().idxmax()
        return best_selling_product

    def calculate_most_popular_country(self):
        merged_data = self.merge_data()
        popular_country = merged_data.groupby('Country_of_Origin')['Amount'].sum().idxmax()
        return popular_country

    def calculate_average_monthly_income(self):
        merged_data = self.merge_data()
        merged_data['Month'] = pd.to_datetime(merged_data['Date_and_time_of_unloading']).dt.month
        average_income = merged_data.groupby('Month')['Profit'].mean()
        return average_income

    def calculate_average_profit_by_country(self):
        merged_data = self.merge_data()
        average_profit = merged_data.groupby('Country_of_Origin')['Profit'].mean()
        return average_profit

    def rank_products_by_price_range(self):
        merged_data = self.merge_data()
        price_ranges = pd.qcut(merged_data['Retail_price'], q=5)
        ranked_products = merged_data.groupby(price_ranges)['Name'].apply(list)
        return ranked_products

    def calculate_most_popular_alcohol_percentage(self):
        merged_data = pd.merge(self.transform_product_data(), self.transform_transaction_data(), on='Product_code')
        popular_alcohol_percentage = merged_data['ABV'].value_counts(normalize=True).idxmax()
        return popular_alcohol_percentage

    def calculate_most_productive_time(self):
        transformed_transaction_data = self.transform_transaction_data()
        transformed_transaction_data['Time'] = pd.to_datetime(
            transformed_transaction_data['Date_and_time_of_unloading']).dt.time
        most_productive_time = transformed_transaction_data['Time'].value_counts().idxmax()
        return most_productive_time

# Instantiate the Database class
db = Database()

# Load merged data to the database
db.extract_product_data()
db.extract_transaction_data()
db.load_merged_data()

# KPI 1 - Calculate the most profitable month based on profit and quantity
most_profitable_month_profit, most_profitable_month_quantity = db.calculate_most_profitable_month()
print("The most profitable month to sell alcohol in terms of profit is:", most_profitable_month_profit)
print("The most profitable month to sell alcohol in terms of quantity is:", most_profitable_month_quantity)

# KPI 2 - Calculate the best selling product
best_selling_product = db.calculate_best_selling_product()
print("The best selling product is:", best_selling_product)

# KPI 3 - Calculate the most popular country from which alcohol is imported
most_popular_country = db.calculate_most_popular_country()
print("The most popular country from which alcohol is imported is:", most_popular_country)

# KPI 4 - Calculate the average monthly income
average_income = db.calculate_average_monthly_income()
print("Average monthly income:")
print(average_income)

# KPI 5 - Calculate the average profit by country
average_profit_by_country = db.calculate_average_profit_by_country()
print("Average profit by country:")
print(average_profit_by_country)

# KPI 6 - Rank products by price range
ranked_products_by_price_range = db.rank_products_by_price_range()
print("Ranked products by price range:")
print(ranked_products_by_price_range)

# KPI 7 - Calculate the most popular alcohol percentage
most_popular_alcohol_percentage = db.calculate_most_popular_alcohol_percentage()
print("The most popular alcohol percentage is:", most_popular_alcohol_percentage)

# KPI 8 - Calculate the most productive time
most_productive_time = db.calculate_most_productive_time()
print("The most productive time for selling products is:", most_productive_time)