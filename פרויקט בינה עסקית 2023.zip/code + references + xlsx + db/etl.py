import pandas as pd
import sqlite3

class BeerETL:
    def __init__(self):
        self.product_data = None
        self.transaction_data = None

    def extract_product_data(self):
        try:
            self.product_data = pd.read_csv('Product_range.csv', encoding='latin-1')
            self.product_data.dropna(inplace=True)
            print("Product data column names:")
            print(self.product_data.columns)
        except FileNotFoundError:
            print("Product_range.csv file not found.")

    def extract_transaction_data(self):
        try:
            self.transaction_data = pd.read_csv('Transactions.csv', encoding='latin-1')
            self.transaction_data.dropna(inplace=True)
            print("Transaction data column names:")
            print(self.transaction_data.columns)
        except FileNotFoundError:
            print("Transactions.csv file not found.")

    def transform_data(self):
        merged_data = pd.merge(self.product_data, self.transaction_data, on='Product_code')
        # Calculate the most saturated month
        merged_data['Month'] = pd.to_datetime(merged_data['Date_and_time_of_unloading']).dt.month
        month_saturated = merged_data.groupby('Month')['Amount'].sum().idxmax()
        # Calculate the best-selling product
        best_selling_product = merged_data.groupby('Name')['Amount'].sum().idxmax()
        # Calculate the most popular importer
        most_popular_importer = merged_data.groupby('Country_of_Origin')['Amount'].sum().idxmax()
        # Calculate the most popular alcohol percentage
        most_popular_alcohol_percentage = merged_data['ABV'].value_counts(normalize=True).idxmax()
        # Calculate average monthly revenue
        merged_data['Revenue'] = merged_data['Amount'] * merged_data['Sale_amount']
        average_monthly_revenue = merged_data.groupby('Month')['Revenue'].mean()
        # Calculate average profit for each importing country
        average_profit_by_country = merged_data.groupby('Country_of_Origin')['Profit'].mean()

        transformed_data = {
            'Most Saturated Month': month_saturated,
            'Best-Selling Product': best_selling_product,
            'Most Popular Importer': most_popular_importer,
            'Most Popular Alcohol Percentage': most_popular_alcohol_percentage,
            'Average Monthly Revenue': average_monthly_revenue,
            'Average Profit by Importing Country': average_profit_by_country
        }
        return transformed_data

    def load_data(self):
        conn = sqlite3.connect('beer_profitability.db')
        transformed_data = pd.DataFrame(self.transform_data())
        transformed_data.to_sql('profitability_data', conn, if_exists='replace', index=False)
        conn.close()
        print("Profitability data successfully loaded to the database.")
        print(transformed_data)

    def save_data_warehouse(self):
        self.extract_product_data()
        self.extract_transaction_data()
        transformed_data = pd.DataFrame(self.transform_data())
        transformed_data.to_csv('beer_profitability.csv', index=False)
        transformed_data.to_excel('beer_profitability.xlsx', index=False)
        print("Data Warehouse successfully saved.")
        print("Location (CSV): beer_profitability.csv")
        print("Location (XLSX): beer_profitability.xlsx")
        print("Transformed Data:")
        print(transformed_data)

etl = BeerETL()
etl.save_data_warehouse()
